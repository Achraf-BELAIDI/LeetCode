package com.alten;

import java.util.Scanner;

public class Reverser  {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Entrez un nombre entier à inverser : ");
        int number = scanner.nextInt();

        Solution solution = new Solution();
        int reversedNumber = solution.reverse(number);

        System.out.println("Nombre inversé : " + reversedNumber);

        scanner.close();
    }
}
