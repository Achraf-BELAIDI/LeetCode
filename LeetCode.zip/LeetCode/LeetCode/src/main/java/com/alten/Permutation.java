package com.alten;

import java.util.List;
import java.util.Scanner;

public class Permutation {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Entrez le nombre d'éléments dans le tableau: ");
        int n = scanner.nextInt();
        int[] nums = new int[n];

        System.out.println("Entrez les éléments du tableau : ");
        for (int i = 0; i < n; i++) {
            System.out.print("Élément " + (i + 1) + ": ");
            nums[i] = scanner.nextInt();
        }

        Solution solution = new Solution();
        List<List<Integer>> permutations = solution.permute(nums);

        System.out.println("Toutes les permutations possibles :");
        for (List<Integer> permutation : permutations) {
            System.out.println(permutation);
        }
        scanner.close();
    }
}
