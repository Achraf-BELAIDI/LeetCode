package com.alten;

import java.util.Scanner;
import java.util.Arrays;

public class DeuxSommes  {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Entrez le nombre d'éléments dans le tableau : ");
        int n = scanner.nextInt();
        int[] nums = new int[n];

        System.out.println("Entrez les éléments du tableau : ");
        for (int i = 0; i < n; i++) {
            System.out.print("Élément " + (i + 1) + ": ");
            nums[i] = scanner.nextInt();
        }

        System.out.print("Entrez la valeur cible : ");
        int target = scanner.nextInt();

        Solution solution = new Solution();
        int[] result = solution.twoSum(nums, target);

        if (result.length == 0) {
            System.out.println("Aucune paire trouvée pour la cible.");
        } else {
            System.out.println("Indices des éléments : " + Arrays.toString(result));
        }

        scanner.close();
    }
}
