package com.alten;

public class Solution {
    public int lengthOfLongestSubstring(String s) {

        int[] charIndex = new int[256];
        int maxLength = 0;
        int left = 0;

        for (int i = 0; i < 256; i++) {
            charIndex[i] = -1;
        }

        for (int right = 0; right < s.length(); right++) {
            char currentChar = s.charAt(right);
            left = Math.max(left, charIndex[currentChar] + 1);
            charIndex[currentChar] = right;
            maxLength = Math.max(maxLength, right - left + 1);
        }

        return maxLength;
    }
}

