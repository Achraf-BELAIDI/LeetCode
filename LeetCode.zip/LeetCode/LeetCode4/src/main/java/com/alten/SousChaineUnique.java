package com.alten;

import java.util.Scanner;

public class SousChaineUnique  {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Entrez une chaîne de caractères : ");
        String s = scanner.nextLine();

        Solution solution = new Solution();
        int result = solution.lengthOfLongestSubstring(s);

        System.out.println("La longueur de la sous-chaîne la plus longue sans caractères répétés est : " + result);

        scanner.close();
    }
}
